if(!dojo._hasResource["dijit.tests._base.wai"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.tests._base.wai"] = true;
dojo.provide("dijit.tests._base.wai");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests._base.wai", dojo.moduleUrl("dijit", "tests/_base/wai.html"));
}

}
